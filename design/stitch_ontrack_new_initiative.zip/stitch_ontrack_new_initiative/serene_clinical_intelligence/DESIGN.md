---
name: Serene Clinical Intelligence
colors:
  surface: '#fdf9f2'
  surface-dim: '#dddad3'
  surface-bright: '#fdf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f7f3ec'
  surface-container: '#f1ede6'
  surface-container-high: '#ebe8e1'
  surface-container-highest: '#e6e2db'
  on-surface: '#1c1c18'
  on-surface-variant: '#514442'
  inverse-surface: '#31302c'
  inverse-on-surface: '#f4f0e9'
  outline: '#837471'
  outline-variant: '#d5c2c0'
  surface-tint: '#7f534d'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#31120f'
  on-primary-container: '#a97871'
  inverse-primary: '#f2b9b1'
  secondary: '#695d45'
  on-secondary: '#ffffff'
  secondary-container: '#efdec0'
  on-secondary-container: '#6e6149'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#410002'
  on-tertiary-container: '#ef453c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#f2b9b1'
  on-primary-fixed: '#31120f'
  on-primary-fixed-variant: '#643c37'
  secondary-fixed: '#f2e0c3'
  secondary-fixed-dim: '#d5c4a8'
  on-secondary-fixed: '#231a08'
  on-secondary-fixed-variant: '#514530'
  tertiary-fixed: '#ffdad6'
  tertiary-fixed-dim: '#ffb4ab'
  on-tertiary-fixed: '#410002'
  on-tertiary-fixed-variant: '#93000a'
  background: '#fdf9f2'
  on-background: '#1c1c18'
  surface-variant: '#e6e2db'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 52px
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.375rem
  space-sm: 0.75rem
  space-md: 1.25rem
  space-lg: 2rem
  space-xl: 3rem
---

## Brand & Style

This design system is engineered specifically for clinicians, medical directors, and healthcare practitioners who need clarity, calm, and prompt decision-making under cognitive load. Rejecting the cluttered, jargon-laden, and cold aesthetic of legacy electronic health records (EHR) and clinical software, it embraces a humanist, warm-minimalist aesthetic. 

The emotional signature is poised, considerate, and profoundly trustworthy. It communicates respect for the physician's time: technical data pipelines, webhooks, or API payload jargon are entirely translated into natural human clinical status ("جاهز لاستقبال اتصالات المرضى", "الرد الآلي مفعل", "استلام المكالمة"). 

The visual style pairs **Warm Minimalism** with tactile, low-friction elements. Surfaces breathe through broad expanses of soothing neutral parchment and warm stone tones, grounded by deep espresso-toned typographic weight and purposeful accents of clinical urgency.

## Colors

The palette is rooted in organic, restorative tones derived from warm editorial aesthetics rather than clinical sterile blues.

- **Primary (`#280B08` - Black Bean):** A velvety, deep umber black. Used for high-contrast primary typography, primary interactive states, and foundational structure. It provides profound visual weight without the harsh, fatiguing edge of synthetic `#000000`.
- **Secondary (`#F9E7C9` - Champagne):** A gentle, warm cream tone that softens the digital canvas. Used for highlighted container backdrops, segmented cards, secondary buttons, and active toggle track fills.
- **Tertiary (`#C92925` - Scarlet Red):** A deliberate, saturated crimson. Reserved exclusively for high-intent clinical actions, critical alerts, urgent incoming calls, and decisive calls-to-action ("استلام المكالمة", "إنهاء المكالمة", "حالة طارئة").
- **Neutral Canvas (`#FBF7F0`):** An airy, soft warm-white background that prevents eye fatigue during extended clinical shifts and creates an inviting tactile paper feel.

### Supporting Semantic Scales
- **Patient Available / Calm Green:** `#2E6F40` for active operational readiness indicators ("جاهز لاستقبال الاتصالات").
- **Subdued Border Neutral:** `#E8DEC8` providing whisper-light boundary definitions that structure data without cluttering sightlines.
- **Muted Text / Secondary Label:** `#6E5D57` for timestamps, metadata, and supporting context.

## Typography

**Plus Jakarta Sans** is designated across all typography levels for its friendly geometry, open apertures, and exceptional optical clarity in both Latin and companion modern Arabic typography pairings. Its rounded qualities bring warmth and humanity, immediately dismantling the cold, intimidating feel of standard hospital software.

### Hierarchy & Voice
- **Headlines:** Set with confident weight (`600`–`700`), remaining concise and conversational.
- **Body:** Open line heights (`1.5` to `1.6`) ensure high glanceability on handheld devices and clinic tablets.
- **Labels & Microcopy:** Clean, sentence-cased clinical phrasing. Status badges leverage `label-sm` with tight vertical metrics for immediate identification without visual disturbance.

## Layout & Spacing

The layout philosophy relies on an unhurried, breathable fluid grid that shields practitioners from visual clutter. 

- **Desktop & Clinical Tablets (1024px+):** A 12-column layout with generous outer margins (`2rem`) and `1.25rem` gutters. Content containers preserve wide white space around patient logs and operational toggles, allowing doctors to focus on one primary workflow at a time.
- **Mobile (Touch & Pocket devices):** Collapses to a unified 4-column flow with tightened margins (`1rem`) and gutters (`0.75rem`), prioritizing one-thumb triage and full-width card structures.
- **Component Padding Rhythm:** Strict application of the `space-*` scale prevents dense data grids. Card interiors use `space-md` for compact status logs and `space-lg` for prominent incoming communication boards.

## Elevation & Depth

To avoid visual fatigue and maintain the non-technical aesthetic, this system completely abandons harsh drop shadows and artificial neon glows in favor of **Tonal Layering** and **Organic Ambient Soft Shadows**.

1. **Base Layer (Level 0):** Neutral `#FBF7F0` backdrop.
2. **Surface Container (Level 1):** Solid white (`#FFFFFF`) or soft Champagne tinted containers (`#F9E7C9` at 40% opacity) outlined by a faint hairline border (`1px solid rgba(40, 11, 8, 0.06)`).
3. **Elevated Floating Surfaces (Level 2 - Call Banners, Active Overlays):** Uses an extra-diffused ambient shadow tinted with Black Bean tone:
   `box-shadow: 0 12px 32px -8px rgba(40, 11, 8, 0.07), 0 4px 12px -2px rgba(40, 11, 8, 0.03);`
4. **State Transition:** Elevation remains calm; interactive elements respond primarily via warm background shifts and micro-scale stabilization rather than abrupt vertical displacement.

## Shapes

The design system incorporates **Roundedness Level 2**, balancing modern software ergonomics with an organic, welcoming character.

- **Standard Buttons & Inputs:** `0.5rem` (8px) radius, creating a comfortable, touch-friendly tap target.
- **Cards & Data Modules:** `1rem` (16px) radius, delivering a clean pillowed appearance that softens data boundaries.
- **Action Pills, Status Badges & Quick Action Chips:** `9999px` (Full Pill) for quick scanning and gentle tactile resonance.

## Components

### Buttons
- **Primary Action (Urgent / Call Handling):** Scarlet Red background (`#C92925`), white typography, rounded `0.75rem` or pill-shaped, height 48px to 56px for error-free tap targets during active calls.
- **Clinical Primary (Standard Work):** Black Bean background (`#280B08`), Champagne text (`#F9E7C9`), refined and authoritative.
- **Secondary / Auxiliary:** Champagne surface (`#F9E7C9`), Black Bean label (`#280B08`), subtle neutral border.
- **Ghost Button:** Transparent background, Black Bean text, 1px hover wash with Champagne tone.

### Patient & Assistant Cards
- Built with crisp white or pale Champagne bases. 
- Top row highlights clear clinical state indicators (e.g., "الرد الآلي مفعل", "مكالمة جديدة واردة").
- Free of raw codes, IDs, or developer logs; data points are expressed as clean, human-readable clinical summaries (e.g., "استفسار بخصوص تحليل الدم", "حجز موعد مراجعة").

### Clinical Status Chips
- Pill-shaped with soft ambient backgrounds.
- Green status ("جاهز للاستقبال"): Soft green tint with a pulsing quiet indicator dot.
- AI Assistant status ("الرد الآلي مفعل"): Champagne background (`#F9E7C9`) with Black Bean typography (`#280B08`) and a modest sparkle or audio wave icon.

### Form Inputs & Selectors
- Background: Warm white (`#FFFFFF`) with a faint border (`#E8DEC8`).
- Focus state: Subtle 1.5px ring in Black Bean (`#280B08`), devoid of harsh blue highlights.
- Clear, calming Arabic typography placeholders written in natural bedside clinical voice.

### Urgent Call HUD (Heads-Up Banner)
- Floating card elevated at Level 2 with high contrast.
- Features prominent caller context, clear visual hierarchy, and side-by-side balanced actions: "استلام المكالمة" (Scarlet Red) alongside "تحويل للمساعد الآلي" (Warm Champagne).